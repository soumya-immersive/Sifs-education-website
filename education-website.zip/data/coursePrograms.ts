export const coursePrograms = [
  { slug: "associate-degree", label: "Associate Degree Program" },
  { slug: "foundation-certificate", label: "Foundation Certificate Program" },
  { slug: "advanced-certificate", label: "Advanced Certificate Program" },
  { slug: "short-term-courses", label: "Short Term Courses" },
  { label: "Professional Courses", slug: "professional-courses" },
  { label: "Classroom Courses", slug: "classroom-courses" },
];
