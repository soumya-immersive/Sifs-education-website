export const trainingPrograms = [
  { slug: "corporate-training", label: "Corporate Training" },
  { slug: "onsite-training", label: "Onsite Training" },
  { slug: "handson-training", label: "Handson Training" },
  { slug: "online-training", label: "Online Training" },
];
